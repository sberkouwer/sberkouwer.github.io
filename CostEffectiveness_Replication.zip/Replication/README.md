# Replication and data package

The Cost-Effectiveness of Clean Cookstove Carbon Mitigation After Adjusting for Additionality and Impact
Susanna B. Berkouwer & Joshua T. Dean — *Climate Change Economics* (2026), DOI: 10.1142/S2010007826500089

Thanks for reading the paper. This package lets you explore the underlying data
and reproduce every number, table, and figure in the article. Everything is
self-contained: all the analysis-ready data ships in `Data/`, and the code reads
only from inside this folder.

If you just want to look at the data, open the files in `Data/` (described
below). If you want to regenerate the exhibits, see *Reproducing the paper* below.

---

## What's in the package

```
Replication/
  README.md              This file.
  Data/                  Analysis-ready datasets (anonymized) — start here to explore.
  Code/                  Stata do-files that produce every exhibit.
  Output/                Where the figures, tables, and a combined PDF are written.
  Static/                Images that are not produced by code (photos, study timeline,
                         study-area map, and the BDM price-distribution figure).
  Borders/               World shapefiles, used only to draw the Figure 3 maps.
```

## The data (`Data/`)

The study is a randomized trial with 955 households in Nairobi, Kenya. All files
are anonymized (no personally identifying information). The main files:

| File | What it contains |
|---|---|
| `Visit123_analysis_replication_noPII.dta` | Main baseline/midline survey: the randomized subsidy, elicited willingness-to-pay, stove purchase and ownership, and household controls. The core RCT data. |
| `Visit123_E1_analysis_replication.dta` | Midline merged with the 1-year endline (charcoal spending outcomes). |
| `Endline1_clean_replication_noPII.dta` | 1-year endline: whether the household still owns a working improved stove. |
| `SMS_clean_sms_replication.dta` | High-frequency SMS survey of charcoal spending (≈2 months after purchase). |
| `SMS_clean_sms_2020_replication_noPII.dta` | The same SMS survey repeated ~1 year later. |
| `SMS_clean_resp_replication.dta` | Each respondent's pre-adoption average SMS spending. |
| `allSURVEYclean.dta` | 3.5-year in-person follow-up survey (ownership, spending, pollution). |
| `allPMdata_hourly.dta` | Hourly PM2.5 air-pollution readings (Purple Air monitors). |
| `hourly_timeuse.dta` | Hourly time-use data (used to flag cooking hours). |
| `fuel_data.xlsx` | Cross-country census shares of households cooking with charcoal/wood (for Figure 3 and Table S2). |
| `charcoaltable_sources_citeyear.txt` | Citations for the census sources in Table S2. |

These come from the trial's two companion papers — Berkouwer & Dean (2022,
*American Economic Review*) and Berkouwer & Dean (2026, *AEJ: Economic Policy*) —
and are the public, anonymized versions of those datasets. Each file here keeps
only the variables this paper actually uses.

## Reproducing the paper

You'll need Stata. To regenerate every exhibit:

1. Open `Code/run_all.do` and set the `$REPL` global to the full path of this
   `Replication` folder. That is the only thing you need to edit.
2. Run it in Stata.

(`run_all.do` also lists a `0_import_data.do` step, left commented out. It only
rebuilds the `Data/` folder from the authors' original project files and is not
needed for replication — the data is already provided. You can ignore it.)

Each do-file maps to specific exhibits:

| Do-file | Produces |
|---|---|
| `1_scalars_context.do` | Every number reported in the text (see *Checking the numbers* below). |
| `2_additionalitytable.do` | Table 1 — subsidy cost per ton of CO₂e abated. |
| `2b_alternativeassumptions.do` | Table 2 — results under alternative assumptions. Every cell is one of the scalars from `1_scalars_context.do`, so this file assembles the table from those values rather than recomputing them. |
| `3_figurestables.do` | Figure 1 (additionality/demand curve), Figure 2 (7-panel impact estimates), Figure S5 (durability), Figure S6 (abatement supply curve), and Table S1 (the IV regressions behind Figure 2). |
| `4_census.do` | Figure 3 (world maps of charcoal/wood users) and Table S2 (the country table). |

Outputs are written to `Output/` — figures (PNG) in `Output/figures`, tables in
`Output/tables`. Nothing outside this folder is modified.

### A single PDF of all exhibits

`Output/figures_and_tables.tex` collects every figure and table (main text and
supplement), each with its caption and label and no body text. Compile it with
pdfLaTeX + BibTeX to get one PDF of all the exhibits — handy for browsing the
results after reading the paper.

### Checking the numbers

`1_scalars_context.do` also writes `Output/scalar_context_report.txt`: for every
statistic in the paper, it lists the computed value alongside each sentence in
the main text that uses it. This makes it easy to trace any number in the
article back to the code that produced it.

The same numbers are written in machine-readable form to `Output/scalars.csv`
(and `Output/scalars.dta`), one row per statistic, plus as LaTeX macros in
`Output/0scalars.tex`. Exhibits that report these numbers rather than
re-estimating them — Table 2, and several figure and table captions — read them
from there, so the text and the exhibits cannot drift apart.

## Software requirements

You need Stata, plus a few user-written packages. Install them once from SSC:

```
ssc install ivreg2         // instrumental-variables regressions
ssc install ranktest       // dependency of ivreg2
ssc install estout         // esttab/eststo/estadd/estpost (regression tables)
ssc install coefplot       // coefficient plots
ssc install palettes       // colorpalette (figure colors)
ssc install colrspace      // dependency of palettes
ssc install spmap          // world maps in 4_census.do
```
`spshape2dta` ships with recent versions of Stata.

## Questions

For questions about the data or code, contact Susanna Berkouwer
(sberkou@wharton.upenn.edu) or Joshua Dean (joshua.dean@chicagobooth.edu).
