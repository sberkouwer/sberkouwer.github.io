* =====================================================================
*  4_census.do  — Table S2 (charcoalwoodtable.txt) and Figure 3 (world
*  maps of charcoal / wood users by country).
*  Self-contained: reads local inputs in $data, shapefiles in $borders.
*  The maps require the -spmap- and -spshape2dta- packages (see run_all.do).
* =====================================================================
if "$REPL"=="" {
	di as error "Run run_all.do first (it sets REPL), or set REPL before running this file."
	exit 198
}
include "$REPL/Code/_paths.do"

*************************************************************************************
* Cooking fuel shares by country
import excel using "$data/fuel_data.xlsx", ///
	cellrange(A3:AI33) firstrow clear
drop if Urban == "See Notes" | Urban==""
destring Urban, replace
drop F-W

local phrase = "X Y Z"
local type = "clean"
local var1 = word("`phrase'",1)
local var2 = word("`phrase'",2)
local var3 = word("`phrase'",3)
rename `var1' urban
rename `var2' rural
rename `var3' total
rename urban `type'_urban
rename rural `type'_rural
rename total `type'_total

local phrase = "AA AB AC"
local type = "charcoal"
local var1 = word("`phrase'",1)
local var2 = word("`phrase'",2)
local var3 = word("`phrase'",3)
rename `var1' urban
rename `var2' rural
rename `var3' total
rename urban `type'_urban
rename rural `type'_rural
rename total `type'_total

local phrase = "AD AE AF"
local type = "wood"
local var1 = word("`phrase'",1)
local var2 = word("`phrase'",2)
local var3 = word("`phrase'",3)
rename `var1' urban
rename `var2' rural
rename `var3' total
rename urban `type'_urban
rename rural `type'_rural
rename total `type'_total

local phrase = "AG AH AI"
local type = "kerosene"
local var1 = word("`phrase'",1)
local var2 = word("`phrase'",2)
local var3 = word("`phrase'",3)
rename `var1' urban
rename `var2' rural
rename `var3' total
rename urban `type'_urban
rename rural `type'_rural
rename total `type'_total

foreach var of varlist * {
	local lower = lower("`var'")
	rename `var' `lower'
}
rename a country
rename b year
lab var total "Total households"
lab var rural "Rural households"
lab var urban "Urban households"

destring *, replace

foreach fuel in clean charcoal wood kerosene {
	g hh_`fuel' = (urban * (`fuel'_urban/100)) + (rural * (`fuel'_rural/100))
	lab var hh_`fuel' "Total households using `fuel'"
}

keep country total hh_charcoal hh_wood
destring hh_charcoal hh_wood, replace
tempfile charcoal
save `charcoal'

*************************************************************************************
* Merge in citation sources and build the table
import delimited "$data/charcoaltable_sources_citeyear.txt", clear delimiter("$$$")
g country = trim(substr(v1, 1, strpos(v1, "&")-2))
g cite = subinstr(v1, country, "", 1)
replace cite = subinstr(cite, "&", "", .)
replace cite = subinstr(cite, "\citeyear{", "(\citeyear{", .)
replace cite = subinstr(cite, "}", "})", .)

keep country cite
merge 1:1 country using `charcoal', assert(2 3) nogen

replace country = "Dem. Rep. of the Congo" if country=="DRC"
replace country = "Other" if (hh_charcoal + hh_wood<5|missing(hh_wood)) & (hh_charcoal<0.1 | missing(hh_charcoal))

preserve
	collapse (sum) total hh_*
	g country = "Total"
	tempfile total
	save `total'
restore

collapse (sum) total hh_* , by(country cite)
append using `total'

g n = 0
replace n = 1 if country=="Other"
replace n = 2 if country=="Total"
replace total = round(total, 0.1)
replace hh_charcoal = round(hh_charcoal, 0.1)
replace hh_wood = round(hh_wood, 0.1)
gsort n -hh_charcoal
tostring *, replace force usedisplayformat

replace total = "~" if country=="Other" | country=="Total"
replace cite = "~\\ " if cite==""
replace country = "\midrule Total" if country=="Total"

g tex = country + " & " + total + " & " + hh_charcoal + " & " + hh_wood + " & " + cite
export delimited tex using "$tabout/charcoalwoodtable.txt", delimiter(tab) replace novarnames

*************************************************************************************
* Figure 3: world maps of charcoal and wood users by country
cd "$borders"
spshape2dta WB_countries_Admin0_10m, replace saving(world)
use world.dta, clear
rename NAME_EN country
replace country="China" if strpos(country, "China")
keep if TYPE=="Sovereign country" | TYPE=="Country"
merge m:1 country using `charcoal', nogen

* Convert households to individuals (x4); hide countries with < 1 million
replace hh_charcoal = hh_charcoal * 4
replace hh_charcoal = . if hh_charcoal < 1
replace hh_wood = hh_wood * 4
replace hh_wood = . if hh_wood < 1

spmap hh_wood using world_shp, id(_ID) fcolor(ebblue%30 ebblue%60 ebblue edkblue) ///
		ocolor(black) ndocolor(gray) ///
		title("Wood users by country", size(huge)) ///
		legorder(hilo) legend(order(5 4 3 2 1) label(2 "2.4 - 8 million") label(3 "8 - 17 million") label(4 "17 - 34 million") label(5 ">34 million") size(vlarge))
graph export "$figout/worldmap_wood.png", replace width(2400)
spmap hh_charcoal using world_shp, id(_ID) fcolor(ebblue%30 ebblue%60 ebblue edkblue) ///
	ocolor(black) ndocolor(gray) ///
	title("Charcoal users by country", size(huge)) ///
	legorder(hilo) legend(order(5 4 3 2 1) label(2 "1 - 4 million") label(3 "4 - 6.4 million") label(4 "6.4 - 12.4 million") label(5 "> 12.4 million") size(vlarge))
graph export "$figout/worldmap_charcoal.png", replace width(2400)