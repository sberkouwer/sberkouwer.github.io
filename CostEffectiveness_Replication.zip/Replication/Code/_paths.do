* =====================================================================
*  _paths.do
*  Central path + macro definitions for the CCE replication package.
*
*  Everything the analysis needs is derived from a single global, $REPL,
*  which points at this Replication folder. $REPL is set in run_all.do
*  (the one line you may need to edit). When you run an individual Code/
*  do-file on its own, it sets $REPL from the current working directory.
*
*  After 0_import_data.do has run once, EVERY analysis path below points
*  inside this folder -- the package is fully self-contained.
* =====================================================================

if "$REPL"=="" {
    di as error "Global REPL is not set. Open run_all.do, set REPL to this folder, and run it."
    exit 198
}

* ---- Folders inside the package ----
global data     "$REPL/Data"        // trimmed datasets (built by 0_import_data.do)
global output   "$REPL/Output"      // generated outputs (figures/, tables/, scalar report)
global figout   "$output/figures"   // generated figures
global tabout   "$output/tables"    // generated tables
global code     "$REPL/Code"
global borders  "$REPL/Borders"     // shapefiles for the world maps
global static   "$REPL/Static"      // images that are NOT code-generated

* Make sure the output subfolders exist
cap mkdir "$output"
cap mkdir "$figout"
cap mkdir "$tabout"

* All trimmed datasets are written into one local folder ($data), so the
* several source aliases the original code used all resolve there:
global dataclean    "$data"
global healthdata   "$data"
global aerclean     "$data"
global analysisdata "$data"

* ---- Shared analysis macros (formerly spread across several masters) ----
* Standard socioeconomic / demographic controls used throughout.
global CONTROLS   "d_charcoalbuy_KSH spend50 savings_KSH b_incomeself_KSH RiskAverse CreditConstrained b_residents b_children d_jikokoalast_years v1_beliefs_annual_mean v1_beliefs_annual_sd"
global TREATMENTS "bdmlo treata a1 a2 treatc c1 c2"

* ---- Graph fonts (match the paper) ----
cap graph set window fontface     "LM Roman 10"
cap graph set window fontfacesans "LM Roman 10"
