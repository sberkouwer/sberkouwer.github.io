* =====================================================================
*  2_additionalitytable.do  — Table 1 (subsidy cost per ton of CO2e abated / additionality).
*  NOTE: Table S1 (the IV regression table) is written by 3_figurestables.do,
*  because it is produced by the same IV regressions as the Figure 2 panels.
*  Self-contained: reads only local trimmed data in $data.
* =====================================================================
set more off
pause off
if "$REPL"=="" {
	di as error "Run run_all.do first (it sets REPL), or set REPL before running this file."
	exit 198
}
include "$REPL/Code/_paths.do"

local totalabate = 4.5742831 // From 1_scalars_context


	local CNR 	= 86.844
	local CR 	= 7.824
	local NC 	= 124.15
	local TJ 	= 0.000027
	local fnrb  = 0.38 
	local frb 	= 1-`fnrb'
	local C 	= (`fnrb'*`CNR') + (`frb'*`CR') 
	local coTJ = `C'+`NC'
	global kgco2 	= `coTJ'*`TJ'		
	local kgcokgchar = $kgco2*1000
	
	
	
use "$data/Visit123_analysis_replication_noPII.dta", clear
keep if Visit2==1
keep if treatc_pooled == 0

keep if price_USD >= 25 & price_USD <= 27 | price_USD >= 10 & price_USD <= 12
g subs_hi = (price_USD >= 10 & price_USD <= 12)

replace price_USD = 26 if price_USD >= 25 & price_USD <= 27 
replace price_USD = 11 if price_USD >= 10 & price_USD <= 12
g cost = 40 - price_USD

su cost if jikokoa==1 & subs_hi==0
local sub_lo = `r(mean)'
local Nlo = `r(N)'
local costlo = `r(N)'*`r(mean)'

su cost if jikokoa==1 & subs_hi==1
local sub_hi = `r(mean)'
local Nhi = `r(N)'
local costhi = `r(N)'*`r(mean)'

local costdiff = `costhi'-`costlo'

su jikokoa if subs_hi==1
local buyhi = `r(mean)'
su jikokoa if subs_hi==0
local buylo = `r(mean)'

clear
set obs 9
g label = "" 
g sublo = .
g subhi = . 

replace label = "Subsidy" 										if _n==1
replace label = "Percentage households who buy"					if _n==2
replace label = "Households who buy$^a$"						if _n==3
replace label = "Total cost" 									if _n==4

replace label = "Additional cost" 								if _n==5
replace label = "Additional stoves sold"						if _n==6

replace label = "Subsidy cost per additional stove sold"		if _n==7
replace label = "Abatement per additional stove sold (\tco)" 	if _n==8
replace label = "Subsidy cost per additional ton of \co abated" if _n==9

foreach s in lo hi {
	replace sub`s' = `sub_`s'' 				if _n==1
	replace sub`s' = 100 * `buy`s'' 		if _n==2
	replace sub`s' = sub`s'[2]			 	if _n==3
	replace sub`s' = sub`s'[1] * sub`s'[3] 	if _n==4	
}

replace subhi = subhi[4] - sublo[4] if _n==5
replace subhi = subhi[3] - sublo[3] if _n==6
replace subhi = subhi[5] / subhi[6] if _n==7
replace subhi = `totalabate' 		if _n==8
replace subhi = subhi[7] / subhi[8] if _n==9

foreach var of varlist sub* {
	replace `var'= round(`var') if _n<=_N-2
	replace `var'= round(`var', 0.01) if _n>=_N-1
	tostring `var', replace format("%10.2fc") force
	replace `var' = subinstr(`var', ".00", "", .)  
	replace `var' = `var' + "\%" if _n==2
	replace `var' = "\\$" + `var' if strpos(label, "cost") | strpos(label, "Subsidy")
}
replace sublo = "~" if _n>=5

g tex = "(" + string(_n) + ") " + label + " & " + sublo  + " & " + subhi + " \\ "
replace tex = tex + " \midrule" if _n==4 | _n==7

export delimited tex using "$tabout/additionality.txt", ///
			delimiter(tab) replace novarnames
