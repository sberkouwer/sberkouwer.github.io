* =====================================================================
*  1_scalars_context.do
*  Computes every number reported in the paper, then writes a report
*  ($output/scalar_context_report.txt) listing, for each number, its
*  value and every sentence in the paper that uses it (its \macro).
*  (Replaces the old 0scalars.tex \newcommand export.)
*  Self-contained: reads only local trimmed data in $data.
* =====================================================================
cap log close
if "$REPL"=="" {
	di as error "Run run_all.do first (it sets REPL), or set REPL before running this file."
	exit 198
}
include "$REPL/Code/_paths.do"
clear
	
	* Store discount values 
	clear 
	set obs 24 
	g monthly2 = 1 * (0.9^(1/12))^(_n-1)
	g monthly1 = monthly2 if _n<=12
	collapse (sum) monthly*
	global disc2 = monthly2[1] / 24
	global disc1 = monthly1[1] / 12
	
	* Store mains 
	global CONTROLS = "d_charcoalbuy_KSH spend50 savings_KSH b_incomeself_KSH RiskAverse CreditConstrained b_residents b_children d_jikokoalast_years v1_beliefs_annual_mean v1_beliefs_annual_sd" 
	local TREATMENTS = "bdmlo treata a1 a2 treatc c1 c2"
	
	global charcoal_kg_price_usd = 0.3 	// USD per KG of charcoal recorded at market stalls 
	global FX 		= 100 				// FX Rate: 100 Kenyan Shillings per dollar, as of April/May 2019 
	
	*******************************************************************************
	* Emissions per KG charcoal  (from MoFuSS, Floess, Gill-Wiehl, etc.)
	*******************************************************************************
	// Conversion of KG charcoal to CO2 from gill wiehl abatement calculations .xlsx
	
	local CNR 	= 86.844
	local CR 	= 7.824
	local NC 	= 124.15
	local TJ 	= 0.000027
	local TJton = `TJ'*1000

		local fnrb  = 0.1
		local frb 	= 1-`fnrb'
		local C 	= (`fnrb'*`CNR') + (`frb'*`CR') 
		local coTJ = `C'+`NC'
		global kgco2lo 	= `coTJ'*`TJ'		
	
		local fnrb  = 1 
		local frb 	= 1-`fnrb'
		local C 	= (`fnrb'*`CNR') + (`frb'*`CR') 
		local coTJ = `C'+`NC'
		global kgco2hi 	= `coTJ'*`TJ'		

		local fnrb  = 0.38 
		local frb 	= 1-`fnrb'
		local C 	= (`fnrb'*`CNR') + (`frb'*`CR') 
		local coTJ = `C'+182.15
		global kgco2ratio6 	= `coTJ'*`TJ'		
		
	local fnrb  = 0.38 
	local frb 	= 1-`fnrb'
	local C 	= (`fnrb'*`CNR') + (`frb'*`CR') 
	local coTJ = `C'+`NC'
	global kgco2 	= `coTJ'*`TJ'		
	local kgcokgchar = $kgco2*1000
	
	 
	 *******************************************************************************
	* Generate key empirical moments
	
	* Proportional reduction in weekly charcoal spending from owning the stove.
	* To replicate this value, run the 1-month SMS IV regression `iv2' in
	* 3_figurestables.do, then:
	*     collapse (mean) amount_weekly, by(respondent_id jikokoa)
	*     su amount_weekly if jikokoa==0
	*     local downperc = (-1) * (_b[jikokoa] / r(mean))
	local downperc 		= 0.39136686
	
	
	* Use baseline to estimate charcoal usage: 
	use d_charcoalbuy_USD using "$data/Visit123_analysis_replication_noPII.dta", clear 
	su d_charcoalbuy_USD, d
		
	local hhcoyear = $kgco2	*52*(`r(mean)' / $charcoal_kg_price_usd)
	local downusdweek 	= `downperc' * `r(mean)'
	
	*******************************************************************************
	* Derivative calculations 
	*******************************************************************************
	
	local downusdyear = `downusdweek' * 52
	local downkgweek = `downusdweek' / $charcoal_kg_price_usd
	local downkgyear = `downkgweek' * 52 
	local downcoyear = `downkgyear' * $kgco2
			
	global pricehi = 26
	global pricelo = 11 
	global price = 40 
	
	*******************************************************************************
	* Visit 2
	*******************************************************************************
	
	use "$data/Visit123_analysis_replication_noPII.dta", clear

	keep if Visit2==1
	keep if treatc_pooled==0

	* PREFERRED METHOD
	su jikokoa if price_USD >= 10 & price_USD <= 12
	local nh = `r(mean)'
	su jikokoa if price_USD >= 25 & price_USD <= 27
	local nl = `r(mean)'
	local buyexp = `nl'
	local buycheap = `nh'
	
	local adoptpp = `nh'-`nl'
	local infra =	`nl'/`nh'
	local stovesperhundred = 100 * (`nh'-`nl') / ((`nh'*29) - (`nl'*14))
	local salecost = 1 / ((`nh'-`nl') / ((`nh'*29) - (`nl'*14)))

	* ALTERNATIVE METHOD
	cou 
	local M = `r(N)'
	cou if finwtp_USD >= 11
	local nh = `r(N)'/`M'
	cou if finwtp_USD >= 26
	local nl = `r(N)'/`M'

	
	* Annual abatement per stove sold: 
	
	*******************************************************************************
	*** Durability
	*******************************************************************************
	
	use price_USD jikokoa respondent_id treatc_pooled Visit2 using "$data/Visit123_analysis_replication_noPII.dta", clear
	keep if Visit2==1
		
	* At 1-year endline
	merge 1:1 respondent_id using "$data/Endline1_clean_replication_noPII.dta", ///
	keepusing(g_jikokoa) keep(1 3)
	g endline1y = _m==3 
	replace g_jikokoa = 0 if missing(g_jikokoa) & endline1y==1
	drop _m
	su g_jikokoa if jikokoa==1 & endline1y==1
	local ownoneyearbuyers = `r(mean)'
	
	su g_jikokoa if jikokoa==0 & endline1y==1
	local ownoneyearnonbuyers = `r(mean)'
	
	* At 3.5-year endline 
	merge 1:1 respondent_id using "$data/allSURVEYclean.dta", ///
		keepusing(health_jikokoa_own treatc_pooled) keep(1 3) 
	g endline35 = _m==3
	replace health_jikokoa_own=0 if missing(health_jikokoa_own) & endline35==1

	cou if jikokoa==0
	cou if jikokoa==0 & (g_jikokoa==1 | health_jikokoa_own==1)
	su g_jikokoa health_jikokoa_own if jikokoa==1

	su health_jikokoa_own if jikokoa==1 & endline35==1  
	local owntfyearbuyers = `r(mean)'
	su health_jikokoa_own if jikokoa==0 & endline35==1  
	local owntfyearnonbuyers = `r(mean)'
	
	* Down-step-down-step
	g durability = 0
	replace durability = (1*g_jikokoa) + ((3.5-1) * health_jikokoa_own) if jikokoa==1
	su durability if jikokoa==1
	replace durability = `r(mean)' if (g_jikokoa==1 | health_jikokoa_own==1) & jikokoa==0
	
	
	* Quadratic
	
	g durabilitylib1 = 0
	replace durabilitylib1 = ( 72.31 / 12) if jikokoa==1 // from analysis.do
	su durabilitylib1  if jikokoa==1
	replace durabilitylib1 = `r(mean)' if (g_jikokoa==1 | health_jikokoa_own==1) & jikokoa==0
		
	collapse (mean) durability*, by(jikokoa)
	
	su durability 
	local durabilityn = `r(min)'
	local durabilityj = `r(max)'
	local durability = `durabilityj' - `durabilityn'
	
	su durabilitylib1
	local durabilityliba = `r(max)' - `r(min)'
	
	su durabilitylib1 if jikokoa==1
	local durabilitylibay = `r(mean)'
	
	
	
	* Each $100 in subsidy causes X years in ownership 
	local yearsperhundred = `stovesperhundred' * `durability'
	
	*******************************************************************************
	***************** Total abatement ********************************
	*******************************************************************************
	local margsavings = `downusdyear' * `durability' * $disc2
	local margext = `downcoyear' * `durability'
		
	*** Aggregate abatement costs 
	local abate = `salecost' / `margext'
	
	local abatefnrbhi = `salecost' / (`downkgyear' * $kgco2hi * `durability')
	local abatefnrblo = `salecost' / (`downkgyear' * $kgco2lo * `durability')
	local abateratiosix = `salecost' / (`downkgyear' * $kgco2ratio6 * `durability')
	
	
	local abateliblo = `salecost' / (`downkgyear' * $kgco2 * `durabilityliba')
	
	* Each $100 in subsidy spending causes X in abatement
	local abateperdollar = 1/`abate'
	
	* Expectation of abatement per stove sold 
	local coperstove = `margext' * (1-`infra')
	
	* Each $100 in subsidy spending causes X in fuel savings 
		
	* Each $1 is $1 cash transfer plus the marginal impact on savings
	* SCC of $120 , $340
	local mvpfnone 	= 1 + ( (`margsavings' - $price + (`margext' * 0) )   / `salecost')
	
	
	local mvpfcolo 	= 1 + ( (0 - $price + (`margext' * 120) ) / `salecost')
	local mvpfcohi 	= 1 + ( (0 - $price + (`margext' * 340) ) / `salecost')
	
	local mvpflo 	= 1 + ( (`margsavings' - $price + (`margext' * 120) ) / `salecost')
	local mvpfhi 	= 1 + ( (`margsavings' - $price + (`margext' * 340) ) / `salecost')

	* Resource cost: 
	local resourcecost = (-1) * ($price - `margsavings') / `margext'
		
	* Comparisons 
	local timesmoreev = 1356/`abate'
	
	local timesmoreevlo = 1356/`abateliblo'
	local timesmoreevhi = 1356/`abatefnrblo'
	
	

	*******************************************************************************
	* IRR 
	*******************************************************************************
			
	clear
	set obs 24
	g month = _n-1
	g cf = (`downusdyear'/12)
	replace cf = -$price if month == 0 
	irr cf
	local ROI = `r(irr)'*12
	
	*******************************************************************************
	* Combine and output 
	*******************************************************************************
		
	clear 
	set obs 1
	g lab = "" 
	g val = "" 

	* Percentages 
	foreach r in downperc ROI infra fnrb ///
		ownoneyearbuyers ownoneyearnonbuyers owntfyearbuyers owntfyearnonbuyers ///
		buyexp buycheap nl nh {
		local `r' = ``r''*100
	}
	
	* Store ALL values: 
	foreach val in downusdweek downusdyear downperc downkgweek downkgyear downcoyear /// 
		margsavings margext abate abatefnrblo abatefnrbhi abateratiosix ///
		mvpfnone mvpflo mvpfhi mvpfcolo mvpfcohi resourcecost ///
		ROI infra stovesperhundred salecost ///
		durability durabilityn durabilityj yearsperhundred ///
		abateliblo ///
		CNR CR NC TJton C coTJ fnrb kgcokgchar /// 
		ownoneyearbuyers ownoneyearnonbuyers owntfyearbuyers owntfyearnonbuyers ///
		buyexp buycheap nl nh hhcoyear coperstove abateperdollar ///
		timesmoreev timesmoreevlo timesmoreevhi ///
		durabilityliba durabilitylibay ///
		{
		
		if ``val''<0.1 				local `val'	= "0" + string(round(``val'', 0.001))
		if ``val''>=0.1 & ``val''<1	local `val' = "0" + string(round(``val'', 0.01))
		if ``val''>=1				local `val' = string(round(``val'', 0.1))
		if ``val''>=10  			local `val' = string(round(``val''))
				
		replace lab = "`val'" 	if _n==_N
		replace val = "``val''" if _n==_N
		set obs `=_N + 1'
	}
	replace val = subinstr(val, "-.", "-0.", .)
	drop if _n==_N
	
	* Dollar amounts: 
	foreach dol in downusdweek downusdyear margsavings ///
		abatefnrblo abatefnrbhi abate salecost ///
		mvpfcolo mvpfcohi mvpfnone mvpflo mvpfhi resourcecost ///
		abateliblo abateratiosix {
		replace val = "US\\$" + val if lab=="`dol'"
	}
	
	* Percentage amounts: 
	foreach per in downperc ROI infra fnrb ///
		ownoneyearbuyers ownoneyearnonbuyers owntfyearbuyers owntfyearnonbuyers ///
		buyexp buycheap nl nh /// 
		{
		replace val = val + "\%" if lab == "`per'"
	}

	sort lab

* =====================================================================
* Write the LaTeX scalar macros (\newcommand ...) consumed by the
* float-only document Output/figures_and_tables.tex.
* =====================================================================
preserve
	g tex = "\newcommand{\" + lab + "}{" + val + "\xspace}"
	export delimited tex using "$output/0scalars.tex", delimiter(tab) replace novarnames
restore

* =====================================================================
* Context report: for each number, its computed value and every sentence
* in the paper that uses its \macro.
*
* The explanatory sentences are HARD-CODED below, taken verbatim from the
* main text (1main.tex), so that this report is fully self-contained and
* depends on no files outside the package. The numeric values are still
* computed live above; only the surrounding sentences are fixed.
*
* Implementation note: every "$" in a sentence is stored as the sentinel
* "@D@" and restored with char(36) by dd() inside Mata, because Stata
* expands a literal $ while parsing the do-file (even inside a mata block).
* =====================================================================
keep lab val
drop if missing(lab) | lab==""
gsort lab

cap erase "$output/scalar_context_report.txt"

mata:
mata clear

string scalar dd(string scalar s) return(subinstr(s, "@D@", char(36), .))

void build_context_report(string scalar outfile)
{
	string colvector labs, vals, S
	real scalar    i, j, fo
	transmorphic   A

	labs = st_sdata(., "lab")
	vals = st_sdata(., "val")

	// --- hard-coded paper sentences, keyed by macro name (no leading backslash) ---
	A = asarray_create()
	asarray(A, "C", (dd("\textcite{Floess2023} furthermore estimate an emissions factor of \C tons of combustion \co and \NC tons of non-combustion \co (i.e..") \ dd("These calculations result in an emissions factor of \coTJ tonnes \co per terajoule, consisting of \C tons of combustion \co and \NC tons of non-combustion \co generated through the production and processing of charcoal..")))
	asarray(A, "NC", (dd("\textcite{Floess2023} furthermore estimate an emissions factor of \C tons of combustion \co and \NC tons of non-combustion \co (i.e..") \ dd("These calculations result in an emissions factor of \coTJ tonnes \co per terajoule, consisting of \C tons of combustion \co and \NC tons of non-combustion \co generated through the production and processing of charcoal..")))
	asarray(A, "TJton", (dd("To convert kilograms of charcoal to \co emissions, we use the following equation, where @D@NR@D@ refers to combustion using non-renewable biomass, @D@R@D@ refers to combustion using renewable biomass, and @D@NC@D@ refers to non-combustion emissions \citep{GillWiehl2024,Floess2023,whitman2011}: \[ ERs = \frac{\text{\shortstack{tonnes of\\ charcoal reduced}}}{\text{hh-year}} * NCV \left( \frac{TJ \text{ of charc}}{\text{tonne of charc}} \right) * \Bigg[ \text{fNRB} \cdot NR + (1 - \text{fNRB}) \cdot R + NC \Bigg] \] These three types of calculations incorporate CO@D@_2@D@, CH@D@_4@D@ and N@D@_2@D@O equivalents and assume a 4-to-1 firewood-to-charcoal conversion ratio.\footnote{ Specifically, we calculate aggregate emissions as follows, with 0 downstream N@D@_2@D@O emissions: \begin{align*} R &= (EF_{CH_4 \text{ of charc}} \cdot GWP_{CH_4}) + (EF_{N_2O \text{ of charc}} \cdot GWP_{N_2O}) = (0.2 \cdot 27.2) + (0.008 \cdot 298) = 7.8 \\ NR &= EF_{CO_2 \text{ of charc}} + (EF_{CH_4 \text{ of charc}} \cdot GWP_{CH_4-NR}) + (EF_{N_2O \text{ of charc}} \cdot GWP_{N_2O}) \\ &= 78.5 + (0.2 \cdot 29.8) + (0.008 \cdot 298) = 86.8 \\ NC &= EF_{CO_2 \text{ of charc upstream}} + (EF_{CH_4 \text{ of charc upstream}} \cdot GWP_{CH_4}) + (EF_{N_2O \text{ of charc upstream}} \cdot GWP_{N_2O}) \\ &= 72 + (1.7 \cdot 29.8) + (0.005 \cdot 298) = 124.2 \end{align*}\vspace{-1.5em} } The net calorific value (NCV) of charcoal is \TJton terajoules per tonne (\cite{Floess2023})..")))
	asarray(A, "abate", (dd("First, carbon abatement through cookstove subsidies costs \abate per ton of \co in this context..") \ dd("Combining these estimates following \autoref{eq:tco}, improved stove subsidies reduce emissions at a cost of \abate per \tco..") \ dd("\begin{table}[t!] \caption{Results under alternative assumptions }\label{tab:opportunitiesmore} \setlength{\tabcolsep}{1pt} \renewcommand{\arraystretch}{1.1}\centering \begin{tabular}[t]{ >{\centering}p{0.1\textwidth} >{\raggedright}p{0.69\textwidth} >{\centering\arraybackslash}m{0.17\textwidth} } \toprule Scenario & Description & \multicolumn{1}{c}{\shortstack{Subsidy spending \\ per ton of\\ \co abated}} \\ \midrule ~ & Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; firewood-to-charcoal ratio of 4:1} & \abate \\ \midrule (1) & Assuming quadratic breakage & \abateliblo \\ \addlinespace[0.5em] (2) & Assuming an fNRB of 10\% & \abatefnrblo \\ (3) & Assuming an fNRB of 100\% & \abatefnrbhi \\ \addlinespace[0.5em] (4) & Assuming a firewood-to-charcoal conversion ratio of 6-to-1 & \abateratiosix \\ \bottomrule \end{tabular}\\[0.5em] \noindent \justifying \footnotesize \emph{Note:} Sensitivity of the estimated subsidy cost per ton of \co abated to alternative assumptions about ownership duration, the fraction of non-renewable biomass (fNRB), and the upstream charcoal production process..") \ dd("\end{table} \section{Discussion} \subsection{Cost-effective \co mitigation} This paper estimates a subsidy cost of abatement of \abate per ton of \co, with estimates ranging between \abateliblo and \abatefnrblo per ton depending on the exact assumptions..")))
	asarray(A, "abatefnrbhi", (dd("Assuming an fNRB of either 10\% or 100\% changes the estimated abatement cost to \abatefnrblo or \abatefnrbhi per ton of \co, respectively..") \ dd("\begin{table}[t!] \caption{Results under alternative assumptions }\label{tab:opportunitiesmore} \setlength{\tabcolsep}{1pt} \renewcommand{\arraystretch}{1.1}\centering \begin{tabular}[t]{ >{\centering}p{0.1\textwidth} >{\raggedright}p{0.69\textwidth} >{\centering\arraybackslash}m{0.17\textwidth} } \toprule Scenario & Description & \multicolumn{1}{c}{\shortstack{Subsidy spending \\ per ton of\\ \co abated}} \\ \midrule ~ & Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; firewood-to-charcoal ratio of 4:1} & \abate \\ \midrule (1) & Assuming quadratic breakage & \abateliblo \\ \addlinespace[0.5em] (2) & Assuming an fNRB of 10\% & \abatefnrblo \\ (3) & Assuming an fNRB of 100\% & \abatefnrbhi \\ \addlinespace[0.5em] (4) & Assuming a firewood-to-charcoal conversion ratio of 6-to-1 & \abateratiosix \\ \bottomrule \end{tabular}\\[0.5em] \noindent \justifying \footnotesize \emph{Note:} Sensitivity of the estimated subsidy cost per ton of \co abated to alternative assumptions about ownership duration, the fraction of non-renewable biomass (fNRB), and the upstream charcoal production process..")))
	asarray(A, "abatefnrblo", (dd("Assuming an fNRB of either 10\% or 100\% changes the estimated abatement cost to \abatefnrblo or \abatefnrbhi per ton of \co, respectively..") \ dd("\begin{table}[t!] \caption{Results under alternative assumptions }\label{tab:opportunitiesmore} \setlength{\tabcolsep}{1pt} \renewcommand{\arraystretch}{1.1}\centering \begin{tabular}[t]{ >{\centering}p{0.1\textwidth} >{\raggedright}p{0.69\textwidth} >{\centering\arraybackslash}m{0.17\textwidth} } \toprule Scenario & Description & \multicolumn{1}{c}{\shortstack{Subsidy spending \\ per ton of\\ \co abated}} \\ \midrule ~ & Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; firewood-to-charcoal ratio of 4:1} & \abate \\ \midrule (1) & Assuming quadratic breakage & \abateliblo \\ \addlinespace[0.5em] (2) & Assuming an fNRB of 10\% & \abatefnrblo \\ (3) & Assuming an fNRB of 100\% & \abatefnrbhi \\ \addlinespace[0.5em] (4) & Assuming a firewood-to-charcoal conversion ratio of 6-to-1 & \abateratiosix \\ \bottomrule \end{tabular}\\[0.5em] \noindent \justifying \footnotesize \emph{Note:} Sensitivity of the estimated subsidy cost per ton of \co abated to alternative assumptions about ownership duration, the fraction of non-renewable biomass (fNRB), and the upstream charcoal production process..") \ dd("\end{table} \section{Discussion} \subsection{Cost-effective \co mitigation} This paper estimates a subsidy cost of abatement of \abate per ton of \co, with estimates ranging between \abateliblo and \abatefnrblo per ton depending on the exact assumptions..")))
	asarray(A, "abateliblo", (dd("\begin{table}[t!] \caption{Results under alternative assumptions }\label{tab:opportunitiesmore} \setlength{\tabcolsep}{1pt} \renewcommand{\arraystretch}{1.1}\centering \begin{tabular}[t]{ >{\centering}p{0.1\textwidth} >{\raggedright}p{0.69\textwidth} >{\centering\arraybackslash}m{0.17\textwidth} } \toprule Scenario & Description & \multicolumn{1}{c}{\shortstack{Subsidy spending \\ per ton of\\ \co abated}} \\ \midrule ~ & Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; firewood-to-charcoal ratio of 4:1} & \abate \\ \midrule (1) & Assuming quadratic breakage & \abateliblo \\ \addlinespace[0.5em] (2) & Assuming an fNRB of 10\% & \abatefnrblo \\ (3) & Assuming an fNRB of 100\% & \abatefnrbhi \\ \addlinespace[0.5em] (4) & Assuming a firewood-to-charcoal conversion ratio of 6-to-1 & \abateratiosix \\ \bottomrule \end{tabular}\\[0.5em] \noindent \justifying \footnotesize \emph{Note:} Sensitivity of the estimated subsidy cost per ton of \co abated to alternative assumptions about ownership duration, the fraction of non-renewable biomass (fNRB), and the upstream charcoal production process..") \ dd("\end{table} \section{Discussion} \subsection{Cost-effective \co mitigation} This paper estimates a subsidy cost of abatement of \abate per ton of \co, with estimates ranging between \abateliblo and \abatefnrblo per ton depending on the exact assumptions..")))
	asarray(A, "abateperdollar", (dd("In addition to abating \abateperdollar \tco, each dollar of subsidy spending therefore also generates significant fuel savings for low-income households..")))
	asarray(A, "abateratiosix", (dd("Scenario (4) assumes a 6:1 conversion ratio of firewood to charcoal, which results in an abatement cost of \abateratiosix..") \ dd("\begin{table}[t!] \caption{Results under alternative assumptions }\label{tab:opportunitiesmore} \setlength{\tabcolsep}{1pt} \renewcommand{\arraystretch}{1.1}\centering \begin{tabular}[t]{ >{\centering}p{0.1\textwidth} >{\raggedright}p{0.69\textwidth} >{\centering\arraybackslash}m{0.17\textwidth} } \toprule Scenario & Description & \multicolumn{1}{c}{\shortstack{Subsidy spending \\ per ton of\\ \co abated}} \\ \midrule ~ & Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; firewood-to-charcoal ratio of 4:1} & \abate \\ \midrule (1) & Assuming quadratic breakage & \abateliblo \\ \addlinespace[0.5em] (2) & Assuming an fNRB of 10\% & \abatefnrblo \\ (3) & Assuming an fNRB of 100\% & \abatefnrbhi \\ \addlinespace[0.5em] (4) & Assuming a firewood-to-charcoal conversion ratio of 6-to-1 & \abateratiosix \\ \bottomrule \end{tabular}\\[0.5em] \noindent \justifying \footnotesize \emph{Note:} Sensitivity of the estimated subsidy cost per ton of \co abated to alternative assumptions about ownership duration, the fraction of non-renewable biomass (fNRB), and the upstream charcoal production process..")))
	asarray(A, "buycheap", (dd("At a high-subsidy price of US\@D@11, \buycheap of study participants are willing to do so..")))
	asarray(A, "buyexp", (dd("At a low-subsidy price of US\@D@26, \buyexp of study participants are willing to buy the energy efficient stove..") \ dd("The higher subsidy increases the number of buyers by 41 percentage points, but the original \buyexp will also receive an increased subsidy, resulting in non-additionality..")))
	asarray(A, "coTJ", (dd("These calculations result in an emissions factor of \coTJ tonnes \co per terajoule, consisting of \C tons of combustion \co and \NC tons of non-combustion \co generated through the production and processing of charcoal..")))
	asarray(A, "coperstove", (dd("If each \emph{additional} stove abates \margext \tco in expectation, and \infra of stoves sold are not additional to the subsidy, then each stove sold abates \coperstove \tco in expectation..")))
	asarray(A, "downcoyear", (dd("Using the methodology discussed in \autoref{sec:sub:convert} to quantify charcoal emissions, this corresponds to a \downcoyear \tco emission reduction per year..") \ dd("Row (8) is derived from \autoref{fig:TC} in \autoref{sec:sub:impact} (each stove purchase increases stove ownership by on average \durability years and abates \downcoyear \tco per year)..") \ dd("Combining the more conservative estimate of \durability with the annual emissions reduction of \downcoyear \tco estimated above, this indicates that each stove sale abates an additional \margext tons of \co over its expected lifetime..") \ dd("The evidence indicates that improved stove ownership abates \downcoyear \tco annually..")))
	asarray(A, "downkgyear", (dd("In terms of abatement, owning a working improved stove for one year reduces household charcoal usage by \downkgyear kilograms of charcoal..") \ dd("\end{figure} Using local charcoal prices to convert charcoal expenditures to kilograms of charcoal consumed, the average reduction of \downusdyear per year thus equates to an annual reduction of \downkgyear kilograms of charcoal..")))
	asarray(A, "downusdyear", (dd("\end{figure} Using local charcoal prices to convert charcoal expenditures to kilograms of charcoal consumed, the average reduction of \downusdyear per year thus equates to an annual reduction of \downkgyear kilograms of charcoal..") \ dd("The average household saves \downusdyear in charcoal expenditures in the first year and US\@D@78 per year after that \citep{Berkouwer2022}..")))
	asarray(A, "durability", (dd("Factoring in observed control group adoption and breakage rates, each additional sale caused by a subsidy generates between \durability and \durabilityliba additional years of improved stove ownership depending on the assumptions about breakage rates after visits (to be conservative, our main estimates throughout the paper use \durability years)..") \ dd("Row (8) is derived from \autoref{fig:TC} in \autoref{sec:sub:impact} (each stove purchase increases stove ownership by on average \durability years and abates \downcoyear \tco per year)..") \ dd("After netting out ownership increases in the control group, each original stove sale causes between \durability and \durabilityliba additional years of stove ownership..") \ dd("Combining the more conservative estimate of \durability with the annual emissions reduction of \downcoyear \tco estimated above, this indicates that each stove sale abates an additional \margext tons of \co over its expected lifetime..")))
	asarray(A, "durabilityj", (dd("We estimate that the improved stoves last on average between \durabilityj and \durabilitylibay years..") \ dd("This results in average stove durability of between \durabilityj and \durabilitylibay years, respectively..") \ dd("The average improved stove buyer therefore saves \margsavings over the average course of \durabilityj years of ownership..")))
	asarray(A, "durabilityliba", (dd("Factoring in observed control group adoption and breakage rates, each additional sale caused by a subsidy generates between \durability and \durabilityliba additional years of improved stove ownership depending on the assumptions about breakage rates after visits (to be conservative, our main estimates throughout the paper use \durability years)..") \ dd("After netting out ownership increases in the control group, each original stove sale causes between \durability and \durabilityliba additional years of stove ownership..")))
	asarray(A, "durabilitylibay", (dd("We estimate that the improved stoves last on average between \durabilityj and \durabilitylibay years..") \ dd("This results in average stove durability of between \durabilityj and \durabilitylibay years, respectively..")))
	asarray(A, "fnrb", (dd("The Model of Fuelwood Savings Scenarios (MoFuSS), a global land use model that measures \co emissions from reductions in woodfuel use, estimates that \fnrb of the biomass used to manufacture charcoal purchased in Nairobi, Kenya is non-renewable (fNRB)..") \ dd("We assume a fraction of non-renewable biomass (fNRB) of \fnrb reflecting the most recent Model of Fuelwood Savings Scenarios (MoFuSS) estimates for urban Kenya used in \textcite{bailis2024} and \textcite{cdm2023} (\autoref{tab:opportunitiesmore} shows sensitivity of the results to a range of 10\% to 100\% fNRB)..")))
	asarray(A, "hhcoyear", (dd("Taken together, this corresponds to average annual emissions of \hhcoyear \tco per household.\footnote{To offer intuition: Each carbon atom in charcoal combines with one O@D@_2@D@ molecule to form CO@D@_2@D@; since CO@D@_2@D@ has molecular mass 44 and carbon atomic mass 12, burning 1\,kg of pure carbon yields 3.67\,kg of CO@D@_2@D@.} By comparison, an average U.S..")))
	asarray(A, "infra", (dd("Third, \infra of total subsidy expenditure flows towards buyers who would have bought the stove even without the higher subsidy..") \ dd("The higher subsidy is cost-effective in part because only \infra of buyers in the high subsidy group were non-additional, and would have bought the stove even with the lower subsidy..") \ dd("At that level, \infra of subsidy spending flows to inframarginal buyers..") \ dd("If each \emph{additional} stove abates \margext \tco in expectation, and \infra of stoves sold are not additional to the subsidy, then each stove sold abates \coperstove \tco in expectation..")))
	asarray(A, "kgcokgchar", (dd("Together, each kilogram of charcoal burned in this context emits \kgcokgchar kilograms of \co..")))
	asarray(A, "margext", (dd("Combining these realized rates, the causal impact of one additional stove sale on emissions is a reduction of \margext \tco..") \ dd("Combining the more conservative estimate of \durability with the annual emissions reduction of \downcoyear \tco estimated above, this indicates that each stove sale abates an additional \margext tons of \co over its expected lifetime..") \ dd("\autoref{sec:sub:impact} subsequently showed that the purchase of one stove reduces total \co emissions by \margext \tco over its expected lifetime..") \ dd("If each \emph{additional} stove abates \margext \tco in expectation, and \infra of stoves sold are not additional to the subsidy, then each stove sold abates \coperstove \tco in expectation..")))
	asarray(A, "margsavings", (dd("Improved cookstove subsidies look even more favorable when factoring in the \margsavings total private fuel savings that stove buyers benefit from on average..") \ dd("The average improved stove buyer therefore saves \margsavings over the average course of \durabilityj years of ownership..")))
	asarray(A, "mvpfcohi", (dd("Net of the cost of manufacturing each stove, each US\@D@1 of subsidy spending generates between \mvpfcolo and \mvpfcohi in avoided climate change damages..")))
	asarray(A, "mvpfcolo", (dd("Net of the cost of manufacturing each stove, each US\@D@1 of subsidy spending generates between \mvpfcolo and \mvpfcohi in avoided climate change damages..")))
	asarray(A, "mvpfhi", (dd("Factoring in the fuel savings, the avoided climate change damages, and the subsidy transfer, and netting this against the cost of manufacturing each stove, each US\@D@1 of subsidy expenditure generates between \mvpflo and \mvpfhi in total societal welfare gain, using the Marginal Value of Public Funds (MVPF) framework (\cite{Hendren2019})..")))
	asarray(A, "mvpflo", (dd("Factoring in the fuel savings, the avoided climate change damages, and the subsidy transfer, and netting this against the cost of manufacturing each stove, each US\@D@1 of subsidy expenditure generates between \mvpflo and \mvpfhi in total societal welfare gain, using the Marginal Value of Public Funds (MVPF) framework (\cite{Hendren2019})..")))
	asarray(A, "nh", (dd("This yields very similar results: \nl of respondents have a WTP above the price with the low subsidy and \nh have a WTP above the price with the high subsidy..")))
	asarray(A, "nl", (dd("This yields very similar results: \nl of respondents have a WTP above the price with the low subsidy and \nh have a WTP above the price with the high subsidy..")))
	asarray(A, "ownoneyearbuyers", (dd("\end{table} After one year, \ownoneyearbuyers of buyers reported owning the stove (and \ownoneyearnonbuyers of non-buyers).\footnote{ Since this survey was conducted in September 2020, due to COVID-19 related public health safety concerns this survey was conducted over the phone and field officers were therefore unable to inspect the stove visually.} During the 3.5-year follow up visit, at which field officers visually inspected the stove, \owntfyearbuyers of buyers still owned a working stove (and \owntfyearnonbuyers of original non-buyers)..")))
	asarray(A, "ownoneyearnonbuyers", (dd("\end{table} After one year, \ownoneyearbuyers of buyers reported owning the stove (and \ownoneyearnonbuyers of non-buyers).\footnote{ Since this survey was conducted in September 2020, due to COVID-19 related public health safety concerns this survey was conducted over the phone and field officers were therefore unable to inspect the stove visually.} During the 3.5-year follow up visit, at which field officers visually inspected the stove, \owntfyearbuyers of buyers still owned a working stove (and \owntfyearnonbuyers of original non-buyers)..")))
	asarray(A, "owntfyearbuyers", (dd("During a follow-up visit 3.5 years after the main study, \owntfyearbuyers of original buyers still own the improved stoves in working condition, and \owntfyearnonbuyers of non-buyers had purchased one by then..") \ dd("\end{table} After one year, \ownoneyearbuyers of buyers reported owning the stove (and \ownoneyearnonbuyers of non-buyers).\footnote{ Since this survey was conducted in September 2020, due to COVID-19 related public health safety concerns this survey was conducted over the phone and field officers were therefore unable to inspect the stove visually.} During the 3.5-year follow up visit, at which field officers visually inspected the stove, \owntfyearbuyers of buyers still owned a working stove (and \owntfyearnonbuyers of original non-buyers)..")))
	asarray(A, "owntfyearnonbuyers", (dd("During a follow-up visit 3.5 years after the main study, \owntfyearbuyers of original buyers still own the improved stoves in working condition, and \owntfyearnonbuyers of non-buyers had purchased one by then..") \ dd("\end{table} After one year, \ownoneyearbuyers of buyers reported owning the stove (and \ownoneyearnonbuyers of non-buyers).\footnote{ Since this survey was conducted in September 2020, due to COVID-19 related public health safety concerns this survey was conducted over the phone and field officers were therefore unable to inspect the stove visually.} During the 3.5-year follow up visit, at which field officers visually inspected the stove, \owntfyearbuyers of buyers still owned a working stove (and \owntfyearnonbuyers of original non-buyers)..")))
	asarray(A, "salecost", (dd("Taken together, incentivizing one additional stove sale requires \salecost in aggregate subsidy spending..") \ dd("Using \autoref{eq:A}, these numbers indicate that incentivizing one additional stove purchase requires an additional \salecost in subsidy expenditure..") \ dd("Repeating the calculations above, this method results in a marginal subsidy cost of \salecost per additional sale..") \ dd("\subsection{Aggregate cost-effectiveness} \autoref{sec:sub:additionality} estimated that incentivizing the sale of one additional stove requires \salecost in subsidy expenditures (across both non-additional and additional buyers)..")))
	asarray(A, "timesmoreev", (dd("Each of the 54 million charcoal stoves currently in use might therefore be able to offer the same abatement opportunity as an electric vehicle, at \timesmoreev times less cost..") \ dd("Electric vehicle subsidies cost US\@D@1,356 in subsidy expenditure per \tco abated \citep{mvpfclimate}: in other words, each dollar of green subsidy towards improved cookstoves abates approximately \timesmoreev times more \co than a dollar of electric vehicle subsidy (estimate range between \timesmoreevhi and \timesmoreevlo depending on the assumptions)..") \ dd("Every dollar of cookstove subsidy reduces \timesmoreev times more \co than a dollar of electric vehicle subsidy..")))
	asarray(A, "timesmoreevhi", (dd("Electric vehicle subsidies cost US\@D@1,356 in subsidy expenditure per \tco abated \citep{mvpfclimate}: in other words, each dollar of green subsidy towards improved cookstoves abates approximately \timesmoreev times more \co than a dollar of electric vehicle subsidy (estimate range between \timesmoreevhi and \timesmoreevlo depending on the assumptions)..")))
	asarray(A, "timesmoreevlo", (dd("Electric vehicle subsidies cost US\@D@1,356 in subsidy expenditure per \tco abated \citep{mvpfclimate}: in other words, each dollar of green subsidy towards improved cookstoves abates approximately \timesmoreev times more \co than a dollar of electric vehicle subsidy (estimate range between \timesmoreevhi and \timesmoreevlo depending on the assumptions)..")))

	fo = fopen(outfile, "w")
	fput(fo, "PAPER-NUMBER CONTEXT REPORT")
	fput(fo, "For each number in the paper: its value, then every sentence that uses its macro.")
	fput(fo, "Paper sources: 1main.tex (sentences hard-coded into 1_scalars_context.do)")
	fput(fo, "=========================================================================")
	for (i=1; i<=rows(labs); i++) {
		fput(fo, "")
		fput(fo, "\" + labs[i] + "  =  " + vals[i])
		if (asarray_contains(A, labs[i])) {
			S = asarray(A, labs[i])
			for (j=1; j<=rows(S); j++) fput(fo, "    - " + S[j])
		}
		else fput(fo, "    (macro not found in the scanned paper text)")
	}
	fclose(fo)
}

build_context_report("$output/scalar_context_report.txt")
end

di as result "Wrote $output/scalar_context_report.txt"
