* =====================================================================
*  3_figurestables.do  — all figures in the paper, plus Table S1:
*    Figure 1  (additionality / demand curve, Inframarginal_constrained_mass)
*    Figure 2  (7-panel impact: TC* panels)
*    Figure S5 (durability: cons1, consquad)
*    Figure S6 (global abatement supply curve)
*  NOTE: also writes Table S1 (Table2_IVcharcoal_PAPER.tex), because that
*  table is produced by the same IV regressions as the Figure 2 panels.
*  Self-contained: reads only local trimmed data in $data.
* =====================================================================
cap log close
if "$REPL"=="" {
	di as error "Run run_all.do first (it sets REPL), or set REPL before running this file."
	exit 198
}
include "$REPL/Code/_paths.do"
clear

* universal "white background" graph option used throughout
local white "plotregion(color(white)) graphregion(color(white)) bgcolor(white)"

local CONTROLS = "d_charcoalbuy_KSH spend50 savings_KSH b_incomeself_KSH RiskAverse CreditConstrained b_residents b_children d_jikokoalast_years v1_beliefs_annual_mean v1_beliefs_annual_sd" 

* CONTROLS2 is the 2018 PILOT controls
local CONTROLS2 = "b_rent b_residents b_children b_incomehh g2_savings d_charcoalbuy"

* CONTROLS3 adds the Dizon-Ross & Jayachandran (2022) practice WTP control
local CONTROLS3 = "`CONTROLS' prac_finwtp item"

include "$code/prog_balance.do"
		
local TREATMENTS = "bdmlo treata a1 a2 treatc c1 c2"
local natureopt1 `" scale(2.7) xlabel(0 "Control   " 1 "Treatment  ") plotregion(color(white)) graphregion(color(white)) bgcolor(white) plotregion(margin(l-2 t+1 b-2)) "'
local natureopts `" `natureopt1' graphregion(margin(l-6 r-8 t-3 b-5)) "'

cap colorpalette Maroon Sienna DarkGoldenRod Teal, globals
local col1 "navy"
local col2 "teal"
local col3 "red"
local col4 "orange"


*** STATS 
use "$data/Visit123_analysis_replication_noPII.dta", clear
keep if Visit2==1 // & treata_pooled==0
cou if abs(price_USD-26)<1
cou if abs(price_USD-11)<1

keep if treatc_pooled==0
su jikokoa if price_USD >= 10 & price_USD <= 12 
su jikokoa if price_USD >= 25 & price_USD <= 27

cou
local N = `r(N)'
cou if finwtp_USD >= 11
local n = `r(N)' 
cou if finwtp_USD >= 26
local m = `r(N)' 


**** DURABILITY GRAPH 

*******************************************************************************
*** Durability
*******************************************************************************
global durability = 1
if $durability==1 {
	
	use jikokoa respondent_id Visit2 g_jikokoa using "$data/Visit123_analysis_replication_noPII.dta", clear
	keep if Visit2==1
	rename g_jikokoa jikokoa_m1
	drop Visit2
		
	* At 1-year endline
	merge 1:1 respondent_id using "$data/Endline1_clean_replication_noPII.dta", ///
	keepusing(g_jikokoa) keep(1 3)
	replace g_jikokoa = 0 if missing(g_jikokoa) & _m==3 
	drop _m
	
	* At 3.5-year endline 
	merge 1:1 respondent_id using "$data/allSURVEYclean.dta", ///
		keepusing(health_jikokoa_own) keep(1 3) nogen
		
	keep respondent_id jikokoa health_jikokoa_own g_jikokoa 
	
	g	own0  = jikokoa
	rename g_jikokoa 			own12 
	rename health_jikokoa_own 	own42
	reshape long own, i(jikokoa respondent_id) j(month)
  
	* Polynomial terms
	gen double m  = month
	gen double m2 = month^2

	* Fit quadratic for jikokoa==1 only; stash coefficients and tmax.
	reg own m m2 if jikokoa == 1, vce(cluster respondent_id)
	scalar bq0 = _b[_cons]
	scalar bq1 = _b[m]
	scalar bq2 = _b[m2]

	scalar disc = bq1^2 - 4*bq2*bq0
	scalar tmax = 42
	if (disc >= 0) {
	  scalar r1 = (-bq1 - sqrt(disc)) / (2*bq2)
	  scalar r2 = (-bq1 + sqrt(disc)) / (2*bq2)
	  scalar a  = cond(r1 > 0, r1, .)
	  scalar b  = cond(r2 > 0, r2, .)
	  scalar mn = min(a, b)
	  if (!missing(mn)) scalar tmax = mn
	}

	* Empirical mean of own at each observed month
	tempfile pts
	collapse (mean) obs_S = own, by(month jikokoa)
	set obs `=_N+1'
	replace jikokoa = 0 if _n==_N
	replace month = tmax if _n==_N
	replace obs_S = obs_S[5] if _n==_N
	save `pts', replace

	* Build grids: 400 points for each group, each spanning 0 to its tmax.
	clear
	set obs 400
	gen byte   jikokoa = 1
	gen double month   = (_n - 1) * `=tmax' / (_N - 1)
	gen double S_quad  = bq0 + bq1*month + bq2*month^2
	replace S_quad = 0 if S_quad < 0
	scalar mean_T = bq0*tmax + bq1*tmax^2/2 + bq2*tmax^3/3
	*** 72.31
  
	append using `pts'

	twoway 	(line    S_quad month if jikokoa==1, sort lcolor(dkorange))   ///
			(scatter obs_S  month if jikokoa==1, mcolor(dkorange)	msymbol(O))          ///
			(scatter obs_S  month if jikokoa==0 & month <= 42, mcolor(gs5)	msymbol(D)),          ///
			ytitle("Pr(still own)") xtitle("Month")                         ///
			ylabel(0(.2)1, format(%3.1f) angle(0))                          ///
			xlabel(0 12 42 `=round(tmax)')                                ///
			ytitle("Percent who own a" "working improved stove") xtitle("Months since main survey") ///
			legend(pos(6) order(2 3) label(2 "Original buyers") label(3 "Original non-buyers")) ///
				scale(1.4) xsize(1) ysize(1) 
		local title = "consquad"
		graph export "$figout/`title'.png", replace width(2400)		
	
	
	use jikokoa respondent_id Visit2 g_jikokoa using "$data/Visit123_analysis_replication_noPII.dta", clear
	keep if Visit2==1
	rename g_jikokoa jikokoa_m1
	drop Visit2
		
	* At 1-year endline
	merge 1:1 respondent_id using "$data/Endline1_clean_replication_noPII.dta", ///
	keepusing(g_jikokoa) keep(1 3)
	replace g_jikokoa = 0 if missing(g_jikokoa) & _m==3 
	drop _m
	
	* At 3.5-year endline 
	merge 1:1 respondent_id using "$data/allSURVEYclean.dta", ///
		keepusing(health_jikokoa_own) keep(1 3) nogen
		
	keep respondent_id jikokoa health_jikokoa_own g_jikokoa
	
	rename g_jikokoa 			own12 
	rename health_jikokoa_own	own42
	reshape long own, i(respondent_id jikokoa) j(month)
	collapse own*, by(jikokoa month)
	
	g sce_obs = 1
	
	* Set up additional points: 
	set obs `=_N+5'
	replace jikokoa = 0 if missing(jikokoa)
	replace jikokoa = 1 if _n==6 | _n==8 | _n==9
	replace month = 42 if _n==8
	replace month = ((_n-6)>0)*54 if missing(month)
	sort month jikokoa
	
	* During the main visit: 
	replace own = jikokoa if month==0
	replace sce_obs=1 if month==0
	
	* Variuos assumptions over future adoption
	replace own = 0 if jikokoa==1 & month==54
	replace own = own[5] if jikokoa==0 & month==54
	replace own = 0 if jikokoa==1 & month==42 & missing(own)
	g sce_mid = 1 if !(month==54 & jikokoa==1)
	g sce_real = 1 if !(month==42 & own==0)
	
	gsort month jikokoa -own
	
	* Most conservative
	
	twoway ///
		(line own month if jikokoa==1, 	lcolor(dkorange)	connect(stepstair) ) ///
		(scatter own month if jikokoa==1 & sce_obs==1,	mcolor(dkorange)	msymbol(O)) ///
		(scatter own month if jikokoa==0 & sce_obs==1, 	mcolor(gs5)			msymbol(D)) ///
		, ytitle("Percent who own a" "working improved stove") xtitle("Months since main survey") ///
		legend(pos(6) order(2 3) label(2 "Original buyers") label(3 "Original non-buyers")) ///
		scale(1.4) xsize(1) ysize(1) 
	
		local title = "cons1"
		graph export "$figout/`title'.png", replace width(2400)		
	
}
*** DEMAND CURVE *** 
global demand = 1
if $demand==1{
	use "$data/Visit123_analysis_replication_noPII.dta", clear
	keep if Visit2==1 // & treata_pooled==0
	keep if treatc_pooled==0
	keep finwtp_USD 
	cumul finwtp_USD , g(cumul_c0a0)
	replace cumul_c0a0 = 1-cumul_c0a0

	preserve
		keep if finwtp_USD >= 11
		g infra = . 
		g marg = . 
		replace infra = 15 if finwtp_USD >= 26
		replace marg = 0 if finwtp_USD >= 26
		replace infra = finwtp_USD - 11 if finwtp_USD < 26
		replace marg = 40 - finwtp_USD if finwtp_USD < 26
		g tot = infra + marg


		cou if finwtp_USD < 26 
		cou if finwtp_USD >= 26 
		su tot 
		su tot if finwtp_USD < 26 

		g fracinfra = infra/tot
		su fracinfra if finwtp_USD < 26
	restore

	bys finwtp_USD (cumul_c0a0): keep if (_n==_N)

	su cumul_c0a0 if abs(finwtp_USD-26)<1
	local lo = `r(mean)'
	local m = `r(N)'*`lo'
	su cumul_c0a0 if abs(finwtp_USD-11)<1
	local hi = `r(mean)'
	local n = `r(N)'*`hi'



	twoway ///
		(scatteri 11 0 11 `lo' 26 `lo' 26 0, recast(area) lwidth(none) fcolor(gs5)) ///
		(scatteri 11 `lo' 11 `hi' 40 `hi' 40 `lo', recast(area) lwidth(none) fcolor(gs10)) /// 
		(scatteri 26 0 26 `lo', recast(line) lwidth(med) lcolor(gs10)) /// 
		(scatteri 11 0 11 `hi', recast(line) lwidth(med) lcolor(gs10)) ///
		(scatteri 40 0 40 1, recast(line) lwidth(medthick) lpattern(dash) lcolor(gs10)) ///
		(lowess finwtp_USD cumul_c0a0, bwidth(0.15) sort lwidth(thick) lcolor(dkorange))  ///
		(scatteri 26 `lo' 11 `hi', mcolor(black) msymbol(O)) ///
		,  ytitle(" ") xtitle("Fraction of people who buy", size(small))  ///
		text(47 0 "{it:P}", size(med)) ///
		text(-0.5 1.05 "{it:Q}", size(med)) ///
		ylabel(11 "Price with high subsidy ($11)" 26 "Price with low subsidy ($26)" 40 "Market price ($40)" , ///
			angle(0) nogrid tlength(3) tlwidth(medthick) tlcolor(gs10)) /// 
		yscale(line extend range(0 45) lcolor(gs10)) /// 
		xlabel(0(0.25)1) ///
		ysize(1) xsize(1.5) aspectratio(1) scale(1.5) ///
		graphregion(margin(t+5)) plotregion(margin(none)) /// 
		legend(cols(1) span position(6) order(1 2) /// 
			label(1 "Payments to non-additional (inframarginal) buyers") ///
			label(2 "Payments to additional (marginal) buyers"))
		
	graph export "$figout/Inframarginal_constrained_mass.png", replace width(2400)


			
}

eststo clear

* TABLE WITH ALL OUTCOMES 

	
	********************* POLLUTION ************************
	
	use "$data/allPMdata_hourly.dta", clear 
	
	merge 1:1 respondent_id datetime using "$data/hourly_timeuse.dta", keep(3) 
	
	keep if ac_cooking_any == 1

	collapse (max) pm2_5_atm, by(respondent_id device_pm)
	tempfile cooking 
	save `cooking'
	
	
	use "$data/Visit123_E1_analysis_replication.dta", clear
	merge 1:1 respondent_id using `cooking', nogen
	merge 1:1 respondent_id using "$data/allSURVEYclean.dta", keepusing(geocluster_id foname decade* hod_pickup rural health_jikokoa_own b_expend7)
	
	g b_expend7_USD = b_expend7/100
	g both = price_USD * treatc_pooled 
	
	global pollregcontrols		`CONTROLS'
	global pollregfe			rural i.device_pm i.geocluster_id 
	global healthregcontrols 	treata_pooled `CONTROLS'  rural i.foname decade_*	i.hod_pickup

	
	cap drop jikokoa
	rename health_jikokoa_own jikokoa 
	eststo pm25: xi: ivreg2 pm2_5_atm finwtp_USD $pollregcontrols $pollregfe $healthregcontrols ///
		(jikokoa=price_USD treatc_pooled both) 
	estadd local Pcontr "Yes" : pm25
	estadd local Scontr "Yes" : pm25
	estadd local outcome "Pollution" : pm25
	estadd local data "PA-II" : pm25
	su pm2_5_atm if jikokoa==0
	estadd scalar cmean = r(mean)
	estadd scalar te = _b[jikokoa]/r(mean)
	
		preserve 
		local var "pm2_5_atm"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		
		
		local title "PM2.5 ({&mu}g/m{sup:3})"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopt1' ///
			graphregion(margin(l-6 r-6 t-3 b-5)) ///
			ytitle("") xtitle("") legend(off) /// 
			text(120 -0.2 "{bf:F}") /// 
			title("`title'", size(medlarge) fcolor(gs13) width(27) bmargin(l-3) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(20)120, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'.png", replace width(2400)
		restore
	eststo yr35: xi: ivreg2 b_expend7_USD finwtp_USD i.treata i.treatc `CONTROLS' $healthregcontrols (jikokoa=price_USD treatc_pooled both) 
	estadd local Pcontr "Yes" : yr35
	estadd local Scontr "Yes" : yr35
	estadd local outcome "Spending" : yr35
	estadd local data "Survey" : yr35
	su b_expend7_USD if jikokoa==0
	estadd scalar cmean = r(mean)
	estadd scalar te = _b[jikokoa]/r(mean)
		
		preserve
		local var "b_expend7_USD"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		local title "Survey (USD)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(7 -0.2 "{bf:G}") /// 
			ytitle("") xtitle("") legend(off) /// 
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(1)7, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'.png", replace width(2400)
		restore		
		
	******************** 1 MONTH + 1 YEAR ENDLINE SURVEY ****************
	
	use "$data/Visit123_E1_analysis_replication.dta", clear
	drop if missing(jikokoa)
	eststo mo1: xi: ivreg2 g_char_week_v3_USD finwtp_USD i.treata i.treatc `CONTROLS' (jikokoa=price_USD) 
	estadd local Pcontr "Yes" : mo1
	estadd local Scontr "Yes" : mo1
	estadd local outcome "Spending" : mo1
	estadd local data "Survey" : mo1
	su g_char_week_v3_USD   if jikokoa==0
	estadd scalar cmean = r(mean)
	estadd scalar te = _b[jikokoa]/r(mean)
		
		preserve
		local var "g_char_week_v3_USD"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		local title "Survey (USD)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(7 -0.2 "{bf:C}") /// 
			ytitle("") xtitle("") legend(off) /// 
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(1)7, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'.png", replace width(2400)
		restore		
	
	eststo yr1: xi: ivreg2 el1_g_char_week_USD finwtp_USD i.treata i.treatc `CONTROLS' (jikokoa=price_USD) 
	estadd local Pcontr "Yes" : yr1
	estadd local Scontr "Yes" : yr1
	estadd local outcome "Spending" : yr1
	estadd local data "Phone" : yr1
	su el1_g_char_week_USD  if jikokoa==0
	estadd scalar cmean = r(mean)
	estadd scalar te = _b[jikokoa]/r(mean)
	su el1_g_char_week_USD if jikokoa==0
			
		preserve
		local var "el1_g_char_week_USD"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		local title "Survey (USD)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(7 -0.2 "{bf:E}") /// 
			ytitle("") xtitle("") legend(off) /// 
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(1)7, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'.png", replace width(2400)
		restore		
		
	******************** 1 YEAR ENDLINE SMSES ****************
	
	use "$data/SMS_clean_sms_2020_replication_noPII.dta", clear
	merge m:1 respondent_id using "$data/Visit123_analysis_replication_noPII.dta", ///
		keepusing(jikokoa price_USD bdmlo finwtp_USD endline_date `CONTROLS' `TREATMENTS' treatc_pooled treata_pooled) 
	keep if _merge == 3 // some people dropped due to non-completion
	drop _merge
	
	* Import pre-adoption average (replace with mean if missing, for treata==0)
	merge m:1 respondent_id using "$data/SMS_clean_resp_replication.dta", keepusing(sms_amount_weekly_pre)
	drop if _merge == 2 // Some people merge == 1: didn't do SMSes last year, but have them this year 
	
	su sms_amount_weekly_pre
	replace sms_amount_weekly_pre=`r(mean)' if missing(sms_amount_weekly_pre)
	
	* Convert KSH to USD and generate IHS
	replace amount_weekly = amount_weekly/100 		// USD
	gen log_amount_weekly = log(amount_weekly)
	gen ihs_amount_weekly = asinh(amount_weekly)
	
	lab var amount_weekly 		"Weekly charcoal spending (USD)"
	lab var log_amount_weekly 	"Log of weekly charcoal spending (USD)"
	lab var ihs_amount_weekly 	"IHS of weekly charcoal spending (USD)"
	
	* Winsorize at 99th percentile:
	assert !missing(amount_weekly)
	su amount_weekly,d
	replace amount_weekly = `r(p99)' if amount_weekly > `r(p99)'
	
	*Create treatment interaction variables
		gen treat_none=(treatc_pooled==0 & treata_pooled==0)
		gen treat_conly=(treatc_pooled==1 & treata_pooled==0)
		gen treat_aonly=(treatc_pooled==0 & treata_pooled==1)
		gen treat_ac=(treatc_pooled==1 & treata_pooled==1)
	
		local t_intercepts "treat_none treat_conly treat_aonly treat_ac"
		
	foreach var of varlist treat_none treat_conly treat_aonly treat_ac {
		gen jikokoa_`var'=jikokoa*`var'
		gen price_USD_`var'=price_USD*`var'
		
		
		if "`var'"=="treat_none" {
			label var jikokoa_`var' "Control"
			label var price_USD_`var' "Control"
		}
		if "`var'"=="treat_conly" {
			label var jikokoa_`var' "Credit Only (pooled)"
			label var price_USD_`var' "Credit Only (pooled)"
		}
		if "`var'"=="treat_aonly" {
			label var jikokoa_`var' "Attention Only (pooled)"
			label var price_USD_`var' "Attention Only (pooled)"
		}
		if "`var'"=="treat_ac" {
			label var jikokoa_`var' "Credit and Attention (pooled)"
			label var price_USD_`var' "Credit and Attention (pooled)"
		}
	
	}
	
	* Prep for IV:
	keep respondent_id jikokoa jikokoa_treat* price_USD price_USD_treat* bdmlo finwtp_USD ///
		amount_weekly log_amount_weekly ihs_amount_weekly ///
		SMS_date midline_date endline_date CsinceV2 TsinceV2	sms_amount_weekly_pre `CONTROLS' `t_intercepts' `TREATMENTS' treatc_pooled
		
*   Time series dummy variables
	su CsinceV2	
	local m = 1
	forv k = `r(min)'/`r(max)' {
		g TsinceV2_`m' = (TsinceV2==`k')
		g CsinceV2_`m' = (CsinceV2==`k')
		g jikokoa_d`m' = jikokoa * CsinceV2_`m'
		g price_d`m'=price_USD * CsinceV2_`m'
		lab var jikokoa_d`m' "`m'"
		lab var price_d`m' "`m'"
		local m = `m'+1
	}	
				
	*** REGRESSIONS WITH SMS DATA ***
	
	bys respondent_id: g n = _n
					
	eststo iv2_sms1yr: xi: ivreg2 amount_weekly finwtp_USD TsinceV2_* i.SMS_date i.treata i.treatc sms_amount_weekly_pre `CONTROLS' (jikokoa=price_USD), cluster(respondent_id)	
	
		preserve
		local var "amount_weekly"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		local title "SMSes (USD)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(7 -0.2 "{bf:D}") /// 
			ytitle("") xtitle("") legend(off) /// 
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(1)7, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'_1yr.png", replace width(2400)
		restore		
	estadd local Pcontr "Yes" : iv2_sms1yr
	estadd local Scontr "Yes" : iv2_sms1yr
	estadd local outcome "Spending" : iv2_sms1yr
	estadd local data "SMSes" : iv2_sms1yr
	su amount_weekly if jikokoa==0
	estadd scalar cmean = r(mean) : iv2_sms1yr
	estadd scalar te = _b[jikokoa]/r(mean)  : iv2_sms1yr
		
	
	******************** 1 MONTH SMSES ****************
	
	use "$data/SMS_clean_sms_replication.dta", clear


	* POST Adoption data only:
	drop if missing(SMS_date) | missing(midline_date)
	keep if (midline_date < SMS_date) 
	
	* Import V2 date: 
	
	preserve
		use "$data/Visit123_analysis_replication_noPII.dta", clear
		
		keep if Visit2==1
		keep respondent_id jikokoa price_USD finwtp_USD g_char_week_v3_USD ///
			bdmlo treata* a1 a2 treatc* c1 c2 ///
			endline_date midline_date `CONTROLS' `TREATMENTS'
			
		rename g_char_week_v3_USD g_char_week_USD 
		isid respondent_id 
		sort respondent_id
		tempfile V2
		save `V2'
		
	restore

	merge m:1 respondent_id using `V2'
	* assert _merge != 1 // Only have Post data for people for whom we have Visit 2 data; some people dropped due to non compliance etc
	keep if _merge ==3
	drop _merge

	* Import pre-adoption average (replace with mean if missing, for treata==0)
	merge m:1 respondent_id using "$data/SMS_clean_resp_replication.dta", keepusing(sms_amount_weekly_pre)
	assert _merge != 1
	keep if _merge == 3
	
	su sms_amount_weekly_pre
	replace sms_amount_weekly_pre=`r(mean)' if missing(sms_amount_weekly_pre)
	
	* Convert KSH to USD and generate IHS
	replace amount_weekly = amount_weekly/100 		// USD
	gen log_amount_weekly = log(amount_weekly)
	gen ihs_amount_weekly = asinh(amount_weekly)
	
	lab var amount_weekly 		"Weekly charcoal spending (USD)"
	lab var log_amount_weekly 	"Log of weekly charcoal spending (USD)"
	lab var ihs_amount_weekly 	"IHS of weekly charcoal spending (USD)"
	
	* Winsorize at 99th percentile:
	assert !missing(amount_weekly)
	su amount_weekly,d
	replace amount_weekly = `r(p99)' if amount_weekly > `r(p99)'
	
	*Create treatment interaction variables
		gen treat_none=(treatc_pooled==0 & treata_pooled==0)
		gen treat_conly=(treatc_pooled==1 & treata_pooled==0)
		gen treat_aonly=(treatc_pooled==0 & treata_pooled==1)
		gen treat_ac=(treatc_pooled==1 & treata_pooled==1)
	
		local t_intercepts "treat_none treat_conly treat_aonly treat_ac"
		
	foreach var of varlist treat_none treat_conly treat_aonly treat_ac {
		gen jikokoa_`var'=jikokoa*`var'
		gen price_USD_`var'=price_USD*`var'
		
		
		if "`var'"=="treat_none" {
			label var jikokoa_`var' "Control"
			label var price_USD_`var' "Control"
		}
		if "`var'"=="treat_conly" {
			label var jikokoa_`var' "Credit Only (pooled)"
			label var price_USD_`var' "Credit Only (pooled)"
		}
		if "`var'"=="treat_aonly" {
			label var jikokoa_`var' "Attention Only (pooled)"
			label var price_USD_`var' "Attention Only (pooled)"
		}
		if "`var'"=="treat_ac" {
			label var jikokoa_`var' "Credit and Attention (pooled)"
			label var price_USD_`var' "Credit and Attention (pooled)"
		}
	
	}
	
	* Prep for IV:
	keep respondent_id jikokoa jikokoa_treat* price_USD price_USD_treat* bdmlo finwtp_USD ///
		amount_weekly log_amount_weekly ihs_amount_weekly ///
		SMS_date midline_date endline_date CsinceV2 TsinceV2	sms_amount_weekly_pre `CONTROLS' `TREATMENTS' `t_intercepts' treatc_pooled
	
	
	

	su CsinceV2	
	local m = 1
	forv k = `r(min)'/`r(max)' {
		g TsinceV2_`m' = (TsinceV2==`k')
		g CsinceV2_`m' = (CsinceV2==`k')
		g jikokoa_d`m' = jikokoa * CsinceV2_`m'
		g price_d`m'=price_USD * CsinceV2_`m'
		lab var jikokoa_d`m' "`m'"
		lab var price_d`m' "`m'"
		local m = `m'+1
	}	
				
	*** REGRESSIONS WITH SMS DATA ***
	
	bys respondent_id: g n = _n
	
	eststo iv2: xi: ivreg2 amount_weekly finwtp_USD TsinceV2_* i.SMS_date i.treata i.treatc sms_amount_weekly_pre `CONTROLS' (jikokoa=price_USD), cluster(respondent_id)
	
		preserve
		local var "amount_weekly"
		cap rename health_jikokoa_own jikokoa

		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]

		local title "SMSes (USD)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(7 -0.2 "{bf:B}") ///
			ytitle("") xtitle("") legend(off) ///
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) ///
			ylabel(0(1)7, angle(0) nogrid labsize(medlarge))
		graph export "$figout/TC`var'.png", replace width(2400)
		restore
	
	estadd local Pcontr "Yes" : iv2
	estadd local Scontr "Yes" : iv2
	estadd local outcome "Spending" : iv2
	estadd local data "SMSes" : iv2
	su amount_weekly if jikokoa==0
	estadd scalar cmean = r(mean) : iv2
	estadd scalar te = _b[jikokoa]/r(mean) : iv2
	label var price_USD 	"BDM Price (USD)"
	label var jikokoa 		"Bought Cookstove (=1)"
	label var finwtp_USD 	"WTP (USD)"
	

	version 12.0 
	
	*** Import Endline Data ***
	use "$data/Visit123_analysis_replication_noPII.dta", clear
	isid respondent_id
	cou
	keep if Visit3==1
	

		*Create treatment interaction variables
		gen treat_none=(treatc_pooled==0 & treata_pooled==0)
		gen treat_conly=(treatc_pooled==1 & treata_pooled==0)
		gen treat_aonly=(treatc_pooled==0 & treata_pooled==1)
		gen treat_ac=(treatc_pooled==1 & treata_pooled==1)
	
		local t_intercepts "treat_none treat_conly treat_aonly treat_ac"
		
	foreach var of varlist treat_none treat_conly treat_aonly treat_ac {
		gen jikokoa_`var'=jikokoa*`var'
		gen price_USD_`var'=price_USD*`var'
		
		
		if "`var'"=="treat_none" {
			label var jikokoa_`var' "Control"
			label var price_USD_`var' "Control"
		}
		if "`var'"=="treat_conly" {
			label var jikokoa_`var' "Credit Only (pooled)"
			label var price_USD_`var' "Credit Only (pooled)"
		}
		if "`var'"=="treat_aonly" {
			label var jikokoa_`var' "Attention Only (pooled)"
			label var price_USD_`var' "Attention Only (pooled)"
		}
		if "`var'"=="treat_ac" {
			label var jikokoa_`var' "Credit and Attention (pooled)"
			label var price_USD_`var' "Credit and Attention (pooled)"
		}
	
	}
	
	
	* (3) Endline Charcoal
	rename g_char_week_v3_USD g_char_week_USD 
	su g_char_week_USD, detail
	replace g_char_week_USD = `r(p99)' if g_char_week_USD>`r(p99)' & !missing(g_char_week_USD)
	g log_g_char_week = log(g_char_week_USD)
	g ihs_g_char_week = asinh(g_char_week_USD)
	
	
	eststo buckKG: xi: ivreg2 bucket_kg finwtp_USD i.treata i.treatc `CONTROLS' (jikokoa=price_USD) 
	estadd local Pcontr "Yes" : buckKG
	estadd local Scontr "Yes" : buckKG
	estadd local outcome "KG" : buckKG
	estadd local data "Buckets" : buckKG
	su bucket_kg if jikokoa==0
	estadd scalar cmean = r(mean) : buckKG
	estadd scalar te = _b[jikokoa]/r(mean)
	
		preserve
		local var "bucket_kg"
		cap rename health_jikokoa_own jikokoa 
	
		collapse (mean) `var', by(jikokoa)
			su `var' if jikokoa==0
			replace `var' = `r(mean)'+_b[jikokoa] if jikokoa == 1
			local lb = `r(mean)' +_b[jikokoa] -  _se[jikokoa]
			local ub = `r(mean)' +_b[jikokoa] +  _se[jikokoa]
		
		local title "Ash (kg)"
		twoway ///
			(bar `var' jikokoa if jikokoa==0, barwidth(0.8) color(`col1')) ///
			(bar `var' jikokoa if jikokoa==1, barwidth(0.8) color(`col2')) ///
			(scatteri `lb' 1 `ub' 1, connect(ascending) msymbol(|) msangle(90) color(black)), ///
			ysize(1.8) xsize(1) `natureopts' ///
			text(4 -0.2 "{bf:A}") /// 
			ytitle("") xtitle("") legend(off) /// 
			title("`title'", size(medlarge) fcolor(gs13) width(30) bmargin(l-2) margin(t+1) alignment(bottom) box) /// 
			ylabel(0(1)4, angle(0) nogrid labsize(medlarge)) 
		graph export "$figout/TC`var'.png", replace width(2400)
		restore
	
	
	
	*** EXPORT RESULTS *** 

	label var price_USD 	"BDM Price (USD)"
	label var jikokoa 		"Owns improved stove (=1)"
	label var finwtp_USD 	"WTP (USD)"

	*** PAPER *** 
	* 1 mo SMSes = iv2
	esttab buckKG iv2 mo1 iv2_sms1yr yr1 pm25 yr35 using "$tabout/Table2_IVcharcoal_PAPER.tex", ///
				keep(jikokoa) b(2) se(2) ///
				order(jikokoa) ///
				scalars("cmean Control Mean" "te Treatment Effect" "Scontr SES controls" "data Data Source") /// 
				mgroups("1 month later" "1 year later" "3.5 years later"  , pattern(1 0 0 1 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(} ) span  erepeat(\cmidrule(lr){@span})) ///
				mtitles("\shortstack{(a) \\ kg}" "\shortstack{(b) \\ USD}" "\shortstack{(c) \\ USD}" "\shortstack{(d) \\ USD}" "\shortstack{(e) \\ USD}" "\shortstack{(f) \\ \PM}" "\shortstack{(g) \\ USD}" ) ///
				nonotes label replace  f booktabs ///
				nostar nonum varwidth(15) wrap
				
				
				
				

* =====================================================================
*  Figure S6 — global marginal-abatement supply curve (was supply_curve.do)
* =====================================================================
	*******************************************************************************
	* Derivative calculations 
	*******************************************************************************
			
	* Abatement per stove: 
	local margext 4.5742831 // matches \margext / additionality.txt row 8 (from 1_scalars_context.do)
	
	* Marginal cost: 
	global price = 40 
	
	* Market size: 
	local Q = 54.2
	
	clear
	g s = . 
	g totalcost = . 
	g totalabate = . 
	
	tempfile results
	save `results'
	
	use "$data/Visit123_analysis_replication_noPII.dta", clear
	keep if Visit2==1
	keep if treatc_pooled==0
	
	cou 
	local M = `r(N)'
	
	cou if finwtp_USD >= $price
	local nl = (`r(N)'/`M') * `Q'
		
	forv s = 0(5)40 {
		
		cou if finwtp_USD >= $price - `s'
		local nh = (`r(N)'/`M') * `Q'
		
		preserve
			use `results', clear
			set obs `=_N + 1'
			replace s = `s' 								if _n==_N
			replace totalcost = `nh' * `s'					if _n==_N
			replace totalabate = (`nh'-`nl') * `margext'	if _n==_N	
			save `results', replace 
		restore
	
	}

	use `results', clear 
	g avecost = totalcost / totalabate
	g margcost = (totalcost - totalcost[_n-1]) / (totalabate - totalabate[_n-1])
	
	twoway ///
		(line totalcost 		totalabate, yaxis(1) lcolor(navy) lpattern(solid)) ///
		(line avecost 			totalabate, yaxis(2) lcolor(dkorange) lpattern(shortdash)) ///
		(line margcost	 		totalabate, yaxis(2) lcolor(teal) lpattern(longdash)) ///
		(scatter totalcost 		totalabate, yaxis(1) mcolor(navy) msymbol(O)) ///
		(scatter avecost 		totalabate, yaxis(2) mcolor(dkorange) msymbol(D)) ///
		(scatter margcost	 	totalabate, yaxis(2) mcolor(teal) msymbol(S)) ///
		, legend(off) ///
		text(2200 250 "Total cost", 	placement(e) size(small)) ///
		text(13 250 "Marginal cost", 	placement(e) size(small) yaxis(2)) ///
		text(9 250 "Average cost", 	placement(e) size(small) yaxis(2)) ///
		ytitle("Total cost (millions USD)", axis(1)) ytitle("Unit cost (USD)", axis(2)) ///
		xtitle("Total abatement (millions of tons of CO{sub:2})                       ") ///
		xlabel(0(50)250) ///
		ylabel(0(500)2000, nogextend) 	yscale(range(0 2200)) /// 
		ylabel(0(4)16, axis(2)) 		yscale(range(0 17.6) axis(2)) ///
		plotregion(margin(none r+20)) scale(1.2) 
	
	graph export "$figout/supplycurve.png", replace width(2400)