* =====================================================================
*  2b_alternativeassumptions.do  — Table 2 (results under alternative
*  assumptions).
*
*  Table 2 reports the headline subsidy cost per ton of CO2e abated next
*  to four sensitivity scenarios. Every cell in the last column is one of
*  the scalars already computed in 1_scalars_context.do:
*
*      Paper estimate                        abate
*      (1) Quadratic breakage                abateliblo
*      (2) fNRB of 10%                       abatefnrblo
*      (3) fNRB of 100%                      abatefnrbhi
*      (4) Firewood-to-charcoal ratio 6:1    abateratiosix
*
*  So this file re-estimates nothing. It reads $output/scalars.dta (written
*  by 1_scalars_context.do) and assembles the body rows of the table, which
*  keeps Table 2 and the numbers quoted in the text from ever drifting apart.
*
*  Writes $tabout/alternativeassumptions.txt, which is \input into the
*  Table 2 tabular in Output/figures_and_tables.tex.
*  Self-contained: reads only files inside this package.
* =====================================================================
set more off
pause off
if "$REPL"=="" {
	di as error "Run run_all.do first (it sets REPL), or set REPL before running this file."
	exit 198
}
include "$REPL/Code/_paths.do"

cap confirm file "$output/scalars.dta"
if _rc {
	di as error "Missing $output/scalars.dta -- run 1_scalars_context.do first."
	exit 601
}

* ---- The five abatement-cost scalars, already formatted (e.g. "US\$7") ----
use lab val using "$output/scalars.dta", clear
tempfile scalars
save `scalars'

* ---- Table body: scenario | description | subsidy cost per ton ------------
clear
set obs 5
g lab      = ""
g scenario = ""
g descr    = ""
g post     = ""

replace lab      = "abate"                                                                                              if _n==1
replace scenario = "~"                                                                                                  if _n==1
replace descr    = "Paper estimate \newline \emph{Sharp breakage assumptions; fNRB of 38\%; " + ///
                   "firewood-to-charcoal ratio of 4:1}"                                                                 if _n==1
replace post     = " \midrule"                                                                                          if _n==1

replace lab      = "abateliblo"                                                                                         if _n==2
replace scenario = "(1)"                                                                                                if _n==2
replace descr    = "Assuming quadratic breakage"                                                                        if _n==2
replace post     = " \addlinespace[0.5em]"                                                                              if _n==2

replace lab      = "abatefnrblo"                                                                                        if _n==3
replace scenario = "(2)"                                                                                                if _n==3
replace descr    = "Assuming an fNRB of 10\%"                                                                           if _n==3

replace lab      = "abatefnrbhi"                                                                                        if _n==4
replace scenario = "(3)"                                                                                                if _n==4
replace descr    = "Assuming an fNRB of 100\%"                                                                          if _n==4
replace post     = " \addlinespace[0.5em]"                                                                              if _n==4

replace lab      = "abateratiosix"                                                                                      if _n==5
replace scenario = "(4)"                                                                                                if _n==5
replace descr    = "Assuming a firewood-to-charcoal conversion ratio of 6-to-1"                                         if _n==5

merge m:1 lab using `scalars', keep(match master) keepusing(val) nogen
assert !missing(val)

g tex = scenario + " & " + descr + " & " + val + " \\ " + post

export delimited tex using "$tabout/alternativeassumptions.txt", ///
			delimiter(tab) replace novarnames
