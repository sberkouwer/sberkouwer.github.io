* =====================================================================
*  run_all.do  —  master runner for the CCE cookstove replication package
*
*  "The cost-effectiveness of clean cookstove carbon mitigation after
*   adjusting for additionality and impact"  (Berkouwer & Dean)
*
*  HOW TO RUN
*  ----------
*  1. Set $REPL below to the full path of THIS Replication folder.
*  2. Run this file in Stata.
*
*  That's it — the analysis-ready data is already in ./Data. (The data-import
*  step is commented out below; it is only for rebuilding ./Data from the
*  original project and is not needed to reproduce the paper.)
*
*  Required Stata packages (install once from SSC if you don't have them; see
*  the README for the full list):
*      ssc install ivreg2
*      ssc install ranktest
*      ssc install estout
*      ssc install coefplot
*      ssc install palettes
*      ssc install colrspace
*      ssc install spmap          // world maps (4_census.do)
*  spshape2dta ships with recent versions of Stata.
* =====================================================================

clear all
set more off

* ---------------------------------------------------------------------
* SET THIS ONCE: the full path to this Replication folder.
* It is the only thing you need to edit to reproduce the paper.
* ---------------------------------------------------------------------
global REPL  "[ROOT]/Replication"

include "$REPL/Code/_paths.do"

* ---------------------------------------------------------------------
* Pipeline
* ---------------------------------------------------------------------
* The data you need is already in ./Data, so you can skip this first step — it is
* left commented out on purpose. It is included only to document how those
* datasets were prepared: it pulls in the raw study files and trims them to the
* variables used here. Running it requires the full original project, which is
* not part of this package, so you do not need it to reproduce anything below.

/* Path to the original Cookstoves project root
global SOURCE "[ROOT]\Cookstoves\"
do "$code/0_import_data.do"
*/

* Numbers in the paper + a report of every sentence each number appears in:
do "$code/1_scalars_context.do"

* Table 1 (additionality). [Table S1 is written by 3_figurestables.do.]
do "$code/2_additionalitytable.do"

* Figures 1, 2, S5, S6 (+ Table S1):
do "$code/3_figurestables.do"

* World census table (Table S2) + charcoal/wood world maps (Figure 3):
do "$code/4_census.do"

di as result "DONE — outputs are in $output"
