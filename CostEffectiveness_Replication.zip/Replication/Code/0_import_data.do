* =====================================================================
*  0_import_data.do
*
*  The ONLY file in this package that reads data from outside the
*  Replication folder. It copies every source dataset the analysis needs
*  into ./Data, keeping ONLY the variables that the rest of the code uses.
*  After this has run once, ./Data is self-contained and every other
*  do-file reads exclusively from $data. Replicators never need this file —
*  ./Data is already provided.
*
*  Each `use <varlist> using ...` below doubles as a check: if Stata
*  reports a variable is not found, that variable was renamed/dropped in
*  the source and the keep-list here should be adjusted.
* =====================================================================

if "$REPL"=="" | "$SOURCE"=="/path/to/Cookstoves" {
    di as error "To rebuild ./Data, set SOURCE above to the Cookstoves project root."
    exit 198
}

* ---- Source folders (only referenced here) --------------------------
global s_aer    "$SOURCE/Main/Replication/Public/Data/Clean"           // 2022 AER public (noPII) data
global s_health "$SOURCE/Health Followup/Data/Analysis Data"           // 2026 health follow-up data
global s_census "$SOURCE/Short paper (scientific, policy audience)/Census Research"

cap mkdir "$data"

* =====================================================================
* 1. Main midline survey (Visit 1/2/3), public noPII version.
*    Used by: scalars, analysis (Table 2 + figures), supply curve, additionality.
* =====================================================================
use respondent_id Visit2 Visit3 jikokoa price_USD finwtp_USD ///
    treatc_pooled treata_pooled bdmlo treata treatc a1 a2 c1 c2 ///
    g_char_week_v3_USD g_jikokoa bucket_kg ihs_bucket_kg_st log_bucket_kg_st ///
    d_charcoalbuy_USD endline_date midline_date ///
    d_charcoalbuy_KSH spend50 savings_KSH b_incomeself_KSH RiskAverse ///
    CreditConstrained b_residents b_children d_jikokoalast_years ///
    v1_beliefs_annual_mean v1_beliefs_annual_sd ///
    using "$s_aer/Visit123_analysis_replication_noPII.dta", clear
compress
save "$data/Visit123_analysis_replication_noPII.dta", replace

* =====================================================================
* 2. Midline + 1-year endline merged file (used for spending/pollution regs).
* =====================================================================
use respondent_id jikokoa price_USD finwtp_USD treata treatc ///
    treatc_pooled treata_pooled g_char_week_v3_USD el1_g_char_week_USD ///
    d_charcoalbuy_KSH spend50 savings_KSH b_incomeself_KSH RiskAverse ///
    CreditConstrained b_residents b_children d_jikokoalast_years ///
    v1_beliefs_annual_mean v1_beliefs_annual_sd ///
    using "$s_aer/Visit123_E1_analysis_replication.dta", clear
compress
save "$data/Visit123_E1_analysis_replication.dta", replace

* =====================================================================
* 3. One-year endline (durability: still owns improved stove).
* =====================================================================
use respondent_id g_jikokoa ///
    using "$s_aer/Endline1_clean_replication_noPII.dta", clear
compress
save "$data/Endline1_clean_replication_noPII.dta", replace

* =====================================================================
* 4. SMS panel — 1 month after adoption.
* =====================================================================
use respondent_id SMS_date midline_date amount_weekly CsinceV2 TsinceV2 ///
    using "$s_aer/SMS_clean_sms_replication.dta", clear
compress
save "$data/SMS_clean_sms_replication.dta", replace

* =====================================================================
* 5. SMS panel — 1 year after adoption (2020 round, noPII).
* =====================================================================
use respondent_id SMS_date midline_date amount_weekly CsinceV2 TsinceV2 ///
    using "$s_aer/SMS_clean_sms_2020_replication_noPII.dta", clear
compress
save "$data/SMS_clean_sms_2020_replication_noPII.dta", replace

* =====================================================================
* 6. SMS respondent-level pre-adoption average.
* =====================================================================
use respondent_id sms_amount_weekly_pre ///
    using "$s_aer/SMS_clean_resp_replication.dta", clear
compress
save "$data/SMS_clean_resp_replication.dta", replace

* =====================================================================
* 7. 3.5-year health follow-up survey (still owns stove, expenditure, FE vars).
* =====================================================================
use respondent_id health_jikokoa_own treatc_pooled geocluster_id ///
    foname rural hod_pickup b_expend7 decade* ///
    using "$s_health/allSURVEYclean.dta", clear
* foname is a numeric field-officer code whose value labels are staff names.
* Strip the labels so the public file carries the code only (no PII).
label values foname
label variable foname ""
compress
save "$data/allSURVEYclean.dta", replace

* =====================================================================
* 8. Hourly PM2.5 pollution data.
* =====================================================================
use respondent_id datetime device_pm pm2_5_atm ///
    using "$s_health/allPMdata_hourly.dta", clear
lab val device_pm 
compress
save "$data/allPMdata_hourly.dta", replace

* =====================================================================
* 9. Hourly time-use data (cooking indicator).
* =====================================================================
use respondent_id datetime ac_cooking_any ///
    using "$s_health/hourly_timeuse.dta", clear
compress
save "$data/hourly_timeuse.dta", replace

* =====================================================================
* 10. Census inputs for the world cooking-fuel maps & table.
*     These are raw inputs (Excel cell ranges / a sources list), so they
*     are copied verbatim rather than variable-trimmed.
* =====================================================================
copy "$s_census/fuel_data.xlsx"                       "$data/fuel_data.xlsx", replace
copy "$s_census/charcoaltable_sources_citeyear.txt"   "$data/charcoaltable_sources_citeyear.txt", replace

di as result "0_import_data.do: local trimmed datasets written to $data"
